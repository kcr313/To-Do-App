//
//  ViewController.swift
//  KisilerUygulamasiEgitim
//
//  Created by kadir ecer on 5.05.2024.
//

import UIKit

class Anasayfa: UIViewController{

    @IBOutlet weak var kisilerTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var viewModel = AnasayfaViewModel()
    var kisilerListesi = [Kisiler]()
    override func viewDidLoad() {
        super.viewDidLoad()
        _ = viewModel.kisilerListesi.subscribe(onNext: { liste in
            
            self.kisilerListesi = liste
            self.kisilerTableView.reloadData()
        })
        searchBar.delegate = self
        
        kisilerTableView.delegate = self
        kisilerTableView.dataSource = self


    }
    
    override func viewWillAppear(_ animated: Bool) {
        viewModel.kisileriyukle()
        // sayfaya dönüldüğünde veriler yüklenmiş olur
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetay"{
            if let kisi = sender as? Kisiler{
                let gidilecekVC = segue.destination as! KisiDetay
                gidilecekVC.kisi = kisi
            }
        }
    }
}


extension Anasayfa:UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        self.viewModel.krepo.ara(aramaKelimesi: searchText)
    }
}

extension Anasayfa:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "kisilerHucre", for: indexPath) as! KisilerHucre
        let kisi = kisilerListesi[indexPath.row]
        cell.labelKisiAd.text = kisi.kisi_ad
        cell.labelKisiTel.text = kisi.kisi_tel
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return kisilerListesi.count
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let kisi = kisilerListesi[indexPath.row]
        performSegue(withIdentifier: "toDetay", sender: kisi)
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let silAction = UIContextualAction(style: .destructive, title: "Sil"){(contextualAction,view,boolValue)in
            let kisi = self.kisilerListesi[indexPath.row]
            let alert = UIAlertController(title: "Silme İşlemi", message: "\(kisi.kisi_ad!) Silinsin mi?", preferredStyle: .alert)
            let iptalAction = UIAlertAction(title: "İptal", style: .cancel)
            alert.addAction(iptalAction)
            let evettAction = UIAlertAction(title: "Evet", style: .destructive){ action in
                self.viewModel.krepo.sil(kisi_id: kisi.kisi_id!)
            }
            alert.addAction(evettAction)
            self.present(alert, animated: true)
        }
       return UISwipeActionsConfiguration(actions: [silAction])
    }
}
