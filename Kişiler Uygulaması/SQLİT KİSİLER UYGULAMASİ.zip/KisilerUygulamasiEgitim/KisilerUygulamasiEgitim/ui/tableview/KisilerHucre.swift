//
//  KisilerHucre.swift
//  KisilerUygulamasiEgitim
//
//  Created by kadir ecer on 7.05.2024.
//

import UIKit

class KisilerHucre: UITableViewCell {

    @IBOutlet weak var labelKisiTel: UILabel!
    @IBOutlet weak var labelKisiAd: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
