//
//  AnasayfaViewModel.swift
//  KisilerUygulamasiEgitim
//
//  Created by kadir ecer on 14.05.2024.
//

import Foundation
import RxSwift

class AnasayfaViewModel{
    var krepo = KisilerRepository()
    var kisilerListesi = BehaviorSubject<[KisilerModel]>(value: [KisilerModel]())
  
    init (){
        kisilerListesi = krepo.kisilerListesi
    }
    func ara(aramaKelimesi:String){
        krepo.ara(aramaKelimesi: aramaKelimesi)
    }
    func sil(kisi:KisilerModel){
        krepo.sil(kisi:kisi)
        kisileriyukle()
    }
    
    func kisileriyukle(){
        krepo.kisileriyukle()
        
        
    }
}
