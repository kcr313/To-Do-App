//
//  KişiKayıtViewModel.swift
//  KisilerUygulamasiEgitim
//
//  Created by kadir ecer on 14.05.2024.
//

import Foundation

class KişiKayıtViewModel{
    var krepo = KisilerRepository()
    func kaydet(kisi_ad:String,kisi_tel:String){
        krepo.kaydet(kisi_ad: kisi_ad, kisi_tel: kisi_tel)
        
    }
}
