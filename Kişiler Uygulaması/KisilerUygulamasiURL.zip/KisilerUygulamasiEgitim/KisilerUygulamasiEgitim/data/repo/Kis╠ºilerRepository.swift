//
//  KişilerRepository.swift
//  KisilerUygulamasiEgitim
//
//  Created by kadir ecer on 14.05.2024.
//

import Foundation
import RxSwift

class KisilerRepository{
    
    var kisilerListesi = BehaviorSubject<[Kisiler]>(value: [Kisiler]())
    
    
    func kaydet(kisi_ad:String,kisi_tel:String){
        var request = URLRequest(url: URL(string:"http://kasimadalan.pe.hu/kisiler/insert_kisiler.php")!)
        request.httpMethod = "POST"
        let postString = "kisi_ad=\(kisi_ad) & kisi_tel=\(kisi_tel)"
        request.httpBody = postString.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request){data,response,error in
            
            do{
                let cevap = try JSONDecoder().decode(CloudCevap.self, from: data!)
                print("Başarı:\(cevap.success!)")
                print("Mesaj:\(cevap.message!)")
            }catch{
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    
    func guncelle(kisi_id:Int,kisi_ad:String,kisi_tel:String){
        var request = URLRequest(url: URL(string:"http://kasimadalan.pe.hu/kisiler/update_kisiler.php")!)
        request.httpMethod =  "POST"
        let postString = "kisi_id=\(kisi_id)& kisi_ad=\(kisi_ad)&kisi_tel=\(kisi_tel)"
        request.httpBody = postString.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request){data,response,error in
            
            do{
                let cevap = try JSONDecoder().decode(CloudCevap.self, from: data!)
                print("Başarı:\(cevap.success!)")
                print("Mesaj:\(cevap.message!)")
                
            }catch{
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    
    
    
    func ara(aramaKelimesi:String){
        var request = URLRequest(url: URL(string:"http://kasimadalan.pe.hu/kisiler/tum_kisiler_arama.php")!)
        request.httpMethod =  "POST"
        let postString = "kisi_ad=\(aramaKelimesi)"
        request.httpBody = postString.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request){data,response,error in
            
            do{
                let cevap = try JSONDecoder().decode(KisilerCevap.self
                                                  , from: data!)
                if let liste = cevap.kisiler{
                    self.kisilerListesi.onNext(liste)
                }
                
            }catch{
                print(error.localizedDescription)
            }
        }.resume()

    }
    
    
    func sil(kisi_id:Int){
        var request = URLRequest(url: URL(string:"http://kasimadalan.pe.hu/kisiler/delete_kisiler.php")!)
        request.httpMethod =  "POST"
        let postString = "kisi_id=\(kisi_id)"
        request.httpBody = postString.data(using: .utf8)
        
        URLSession.shared.dataTask(with: request){data,response,error in
            
            do{
                let cevap = try JSONDecoder().decode(CloudCevap.self, from: data!)
                print("Başarı:\(cevap.success!)")
                print("Mesaj:\(cevap.message!)")
                
            }catch{
                print(error.localizedDescription)
            }
        }.resume()

    }
    
    
    func kisileriyukle(){
        let url = URL(string:"http://kasimadalan.pe.hu/kisiler/tum_kisiler.php")!
        
        URLSession.shared.dataTask(with: url){data,response,error in
            
            do{
                let cevap = try JSONDecoder().decode(KisilerCevap.self
                                                  , from: data!)
                if let liste = cevap.kisiler{
                    self.kisilerListesi.onNext(liste)
                }
                
            }catch{
                print(error.localizedDescription)
            }
            
            
        }.resume()
    }
}
