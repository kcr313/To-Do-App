//
//  KisilerCevap.swift
//  KisilerUygulamasiEgitim
//
//  Created by kadir ecer on 16.05.2024.
//

import Foundation

class KisilerCevap:Codable{
    var kisiler:[Kisiler]?
    var success:Int?
}
