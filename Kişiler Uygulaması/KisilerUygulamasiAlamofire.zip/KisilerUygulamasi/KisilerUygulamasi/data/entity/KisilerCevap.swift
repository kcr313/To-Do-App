//
//  KisilerCevap.swift
//  KisilerUygulamasi
//
//  Created by Kasım on 16.05.2024.
//

import Foundation

class KisilerCevap : Codable {
    var kisiler:[Kisiler]?
    var success:Int?
}
