//
//  CRUDCevap.swift
//  KisilerUygulamasi
//
//  Created by Kasım on 16.05.2024.
//

import Foundation

class CRUDCevap : Codable {
    var success:Int?
    var message:String?
}
